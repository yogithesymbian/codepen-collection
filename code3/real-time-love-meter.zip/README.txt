A Pen created at CodePen.io. You can find this one at https://codepen.io/kindofone/pen/Hrfgx.

 Experimenting with CodePen love by showing a love meter that updates using Ajax calls in real-time according to the love count of this pen on CodePen. Join the beat.