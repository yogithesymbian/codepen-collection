A Pen created at CodePen.io. You can find this one at https://codepen.io/ScottMarshall/pen/azNpwR.

 A fully responsive blog grid using pure css, bootstrap and a little bit of magic!