A Pen created at CodePen.io. You can find this one at https://codepen.io/p_elkoshairy/pen/jxNxaO.

 