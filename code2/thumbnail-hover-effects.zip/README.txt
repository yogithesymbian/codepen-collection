A Pen created at CodePen.io. You can find this one at https://codepen.io/nikhil8krishnan/pen/LrKrPm.

 Pure CSS3 image thumbnail hover effects, also we can easily change the grid item per row using by sass variable.