A Pen created at CodePen.io. You can find this one at https://codepen.io/cristina-silva/pen/XXOpga.

 Who needs a javascript plugin? Create a tooltip using only CSS.

Check out the full article on the thoughtbot blog: https://robots.thoughtbot.com/you-don-t-need-javascript-for-that