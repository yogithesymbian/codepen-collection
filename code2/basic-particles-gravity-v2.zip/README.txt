A Pen created at CodePen.io. You can find this one at https://codepen.io/Capse/pen/KdJvRM.

 Still working on physics. 
Click for jump .
Move to propulse.
Open controls and play with settings.
Enjoy !