A Pen created at CodePen.io. You can find this one at https://codepen.io/vineethtr/pen/xbyvmZ.

 Radio Button List with mouse hover moving marker on css3