A Pen created at CodePen.io. You can find this one at https://codepen.io/jalasem/pen/VprJWL.

 Android Phone Frame