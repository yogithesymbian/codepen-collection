A Pen created at CodePen.io. You can find this one at https://codepen.io/malbarmawi/pen/zKoLEp.

 Count down example with simple Javascript  implimination 