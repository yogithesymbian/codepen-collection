A Pen created at CodePen.io. You can find this one at https://codepen.io/arjunamgain/pen/qdpWLL.

 Filter Menu  created by Anton Aheichanka that has been converted into web version. Here is the original link of  https://dribbble.com/shots/1956586-Filter-Menu