A Pen created at CodePen.io. You can find this one at https://codepen.io/wilder_taype/pen/mOaoQq.

 For loop - Js or  Js - For loop For loop - Js, Grid responsive