var text = "";
var  i;
for(i = 0; i < 18; i++ ){
  text += "<li><div class='box'><i class='fa fa-check-circle fa-4x'></i></div> </li>";
  a.innerHTML = text;
}