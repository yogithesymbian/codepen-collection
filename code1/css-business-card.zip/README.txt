A Pen created at CodePen.io. You can find this one at https://codepen.io/keithpickering/pen/XJeJMv.

 The physical world is *so* last year. Save the trees with a digital business card.