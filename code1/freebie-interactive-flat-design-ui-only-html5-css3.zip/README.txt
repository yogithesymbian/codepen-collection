A Pen created at CodePen.io. You can find this one at https://codepen.io/jlalovi/pen/bIyAr.

 Inspired by: 
http://graphicburger.com/flat-design-ui-components/

Line-chart and donut-chart made by @Kseso: http://codepen.io/Kseso/pen/phiyL