A Pen created at CodePen.io. You can find this one at https://codepen.io/codeparadox/pen/EEdxKq.

 For the Best View watch in Full Screen

I tried to create a android Mobile prototype in Html,Css and JavaScript.
There is not much functionality in it. It is just a layout. Still It is in Developing  phase, more functionality will be add in future.