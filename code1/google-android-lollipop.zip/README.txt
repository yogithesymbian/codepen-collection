A Pen created at CodePen.io. You can find this one at https://codepen.io/simoberny/pen/LVBgyE.

 The interface of Android lollipop lockscreen & some other page with the use of restart Css animation script and css icon designed. Moreover i add the jquery touch event to unlock the phone (swipeleft camera, swiperight dialer, swipeup unlock)